#!/bin/bash

# 🔑 Скрипт для изменения токена бота

echo "🤖 Изменение токена Telegram бота"
echo "=================================="
echo ""

# Показываем текущий токен (частично скрыт)
CURRENT_TOKEN=$(grep "BOT_TOKEN=" .env | cut -d'=' -f2)
if [ -n "$CURRENT_TOKEN" ]; then
    HIDDEN_TOKEN="${CURRENT_TOKEN:0:10}...${CURRENT_TOKEN: -10}"
    echo "Текущий токен: $HIDDEN_TOKEN"
else
    echo "Текущий токен: не найден"
fi

echo ""
echo "Введите новый токен бота (получите у @BotFather):"
read NEW_TOKEN

# Проверка что токен не пустой
if [ -z "$NEW_TOKEN" ]; then
    echo "❌ Ошибка: токен не может быть пустым!"
    exit 1
fi

# Проверка формата токена (базовая)
if [[ ! "$NEW_TOKEN" =~ ^[0-9]+:[A-Za-z0-9_-]+$ ]]; then
    echo "⚠️  Предупреждение: формат токена выглядит неправильно"
    echo "Токен должен быть вида: 123456789:ABCdefGHIjklMNOpqrsTUVwxyz"
    echo ""
    echo "Продолжить всё равно? (y/n)"
    read CONFIRM
    if [ "$CONFIRM" != "y" ]; then
        echo "Отменено"
        exit 0
    fi
fi

# Создаём резервную копию
cp .env .env.backup.$(date +%Y%m%d_%H%M%S)
echo "✅ Резервная копия создана"

# Заменяем токен
if grep -q "BOT_TOKEN=" .env; then
    # Токен уже есть - заменяем
    sed -i.tmp "s|BOT_TOKEN=.*|BOT_TOKEN=$NEW_TOKEN|" .env
    rm -f .env.tmp
    echo "✅ Токен обновлён"
else
    # Токена нет - добавляем
    echo "BOT_TOKEN=$NEW_TOKEN" >> .env
    echo "✅ Токен добавлен"
fi

echo ""
echo "🎉 Готово!"
echo ""
echo "Теперь перезапустите бота:"
echo "  docker-compose restart"
echo ""
echo "Или если бот запущен локально:"
echo "  python run_modern_bot.py"
