#!/bin/bash

# Скрипт для создания архива папки docker_deploy
# Используйте этот скрипт для быстрого создания архива для переноса

echo "🚀 Создание архива для развертывания бота..."

# Имя архива с датой
ARCHIVE_NAME="bot_deploy_$(date +%Y%m%d_%H%M%S).tar.gz"

# Переходим в родительскую папку
cd "$(dirname "$0")/.."

# Создаем архив, исключая ненужные файлы
echo "📦 Архивируем папку docker_deploy..."
tar -czf "$ARCHIVE_NAME" \
    --exclude="*.pyc" \
    --exclude="__pycache__" \
    --exclude=".DS_Store" \
    --exclude="*.db" \
    --exclude="*.db-shm" \
    --exclude="*.db-wal" \
    --exclude="*.pickle" \
    docker_deploy/

if [ $? -eq 0 ]; then
    SIZE=$(du -h "$ARCHIVE_NAME" | cut -f1)
    echo "✅ Архив создан успешно!"
    echo "📂 Файл: $ARCHIVE_NAME"
    echo "💾 Размер: $SIZE"
    echo ""
    echo "Теперь можете перенести файл $ARCHIVE_NAME на другой компьютер"
    echo "и распаковать его командой:"
    echo "  tar -xzf $ARCHIVE_NAME"
else
    echo "❌ Ошибка при создании архива!"
    exit 1
fi
