# 🚀 Развертывание Telegram-бота по заключениям через Docker

Эта папка содержит все необходимые файлы для запуска бота на любом компьютере с Docker.

## 📋 Содержимое папки

- `Dockerfile` - конфигурация Docker-образа
- `docker-compose.yml` - конфигурация для запуска контейнера
- `requirements.txt` - Python-зависимости
- `.env` - переменные окружения (токены и настройки)
- `run_modern_bot.py` - точка входа приложения
- `template.docx` - шаблон для генерации заключений
- `modern_bot/` - весь код бота
- `logs/`, `backups/`, `config/`, `documents/`, `documents_archive/`, `photos/` - рабочие директории

## ⚙️ Предварительные требования

На целевом компьютере должны быть установлены:
- **Docker** (версия 20.10 или выше)
- **Docker Compose** (версия 1.29 или выше)

### Установка Docker:
- **Windows/Mac**: [Docker Desktop](https://www.docker.com/products/docker-desktop/)
- **Linux**: [Docker Engine](https://docs.docker.com/engine/install/)

## 🔧 Настройка перед запуском

### 1. Проверьте файл `.env`

Откройте файл `.env` и убедитесь, что все параметры заполнены правильно:

```env
BOT_TOKEN=ваш_токен_бота
MAIN_GROUP_CHAT_ID=-1002381542769
DEFAULT_ADMIN_IDS=2064900,7511144435,960665399
```

⚠️ **Важно**: Если вы переносите бота на новый компьютер, проверьте что токен актуален!

### 2. Проверьте порты

Убедитесь что порт **8080** свободен на целевом компьютере.

Проверить можно командой:
```bash
# Linux/Mac
lsof -i :8080

# Windows (PowerShell)
netstat -ano | findstr :8080
```

## 🚀 Запуск бота

### Вариант 1: Запуск через Docker Compose (рекомендуется)

```bash
# Перейдите в папку docker_deploy
cd путь/к/docker_deploy

# Запустите контейнер в фоновом режиме
docker-compose up -d

# Проверьте статус
docker-compose ps

# Посмотрите логи
docker-compose logs -f
```

### Вариант 2: Запуск через Docker вручную

```bash
# Соберите образ
docker build -t modern_bot .

# Запустите контейнер
docker run -d \
  --name modern_bot \
  -p 8080:8080 \
  --env-file .env \
  -v $(pwd)/logs:/app/logs \
  -v $(pwd)/backups:/app/backups \
  -v $(pwd)/documents:/app/documents \
  modern_bot
```

## 📊 Управление ботом

### Остановка бота
```bash
docker-compose down
```

### Перезапуск бота
```bash
docker-compose restart
```

### Просмотр логов
```bash
# Все логи
docker-compose logs

# Последние 100 строк с обновлением в реальном времени
docker-compose logs -f --tail=100
```

### Обновление кода
```bash
# Остановите контейнер
docker-compose down

# Пересоберите образ
docker-compose build

# Запустите заново
docker-compose up -d
```

## 🔍 Проверка работы

### Healthcheck API
Бот предоставляет API для проверки состояния:

```bash
# Проверка здоровья
curl http://localhost:8080/health

# Должен вернуть: {"status":"ok"}
```

### Логи в файлах
Логи сохраняются в папке `logs/`:
- `bot.log` - основные логи работы бота
- `errors.log` - логи ошибок

## 📁 Персистентные данные

Следующие данные сохраняются между перезапусками:
- **База данных**: `user_data.db`
- **Логи**: `logs/`
- **Резервные копии**: `backups/`
- **Документы**: `documents/` и `documents_archive/`
- **Фотографии**: `photos/`

## ⚠️ Troubleshooting

### Бот не запускается
```bash
# Проверьте логи контейнера
docker-compose logs

# Проверьте что .env файл правильный
cat .env
```

### Ошибка "port already in use"
```bash
# Измените порт в docker-compose.yml
# Замените "8080:8080" на "8081:8080" (или другой свободный порт)
```

### Permission denied на Linux
```bash
# Добавьте пользователя в группу docker
sudo usermod -aG docker $USER

# Перелогиньтесь или выполните
newgrp docker
```

## 🔐 Безопасность

- ⚠️ **НЕ публикуйте** файл `.env` в публичных репозиториях!
- Храните резервные копии `.env` в безопасном месте
- Регулярно проверяйте логи на наличие подозрительной активности

## 📞 Поддержка

Если возникли проблемы:
1. Проверьте логи: `docker-compose logs`
2. Убедитесь что .env заполнен правильно
3. Проверьте что Docker работает: `docker ps`
4. Проверьте healthcheck: `curl http://localhost:8080/health`

---

**Готово! Бот должен работать. Удачи! 🎉**
